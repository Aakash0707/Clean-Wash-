
import { useNavigate } from 'react-router-dom';
import LandingPage from './LandingPage';

const Index = () => {
  return <LandingPage />;
};

export default Index;
